#ifndef RENTAL_SYSTEM_H
#define RENTAL_SYSTEM_H

#include <memory>
#include <vector>

class Vehicle;

class RentalSystem {
private:
    std::vector<std::unique_ptr<Vehicle>> vehicles;

public:
    void addVehicle(std::unique_ptr<Vehicle> vehicle);

    Vehicle* findVehicleByID(int vehicleID);
    const Vehicle* findVehicleByID(int vehicleID) const;

    void displayAllVehicles() const;
    void displayAvailableVehicles() const;
};

#endif